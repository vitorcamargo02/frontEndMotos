import Moto from '../core/Moto';
let motosList: Moto[] = [
  new Moto(1, "CBR 1000RR-R",
    "A moto muito R",
    "Vendida",
  ),
  new Moto(2, "S1000RR",
    "A moto mais rapida",
    "Disponivel",
  )
]
let proximoId = motosList.length + 1;

export const fetchMotos = async (): Promise<Moto[]> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return motosList;
  } catch (error) {
    throw new Error('Erro ao buscar motos');
  }
};

export const cadastrarMoto = async (novoMoto: Moto): Promise<Moto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    novoMoto.id = proximoId++;
    motosList.push(novoMoto);
    return novoMoto;
  } catch (error) {
    console.error("Erro ao cadastrar moto:", error);
    throw error;
  }
};

export const atualizarMoto = async (motoAtualizado: Moto): Promise<Moto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const index = motosList.findIndex((moto) => moto.id === motoAtualizado.id);
    if (index !== -1) {
      motosList[index] = motoAtualizado;
      return motoAtualizado;
    } else {
      throw new Error('Moto não encontrada');
    }
  } catch (error) {
    console.error("Erro ao atualizar moto:", error);
    throw error;
  }
};

export const excluirMoto = async (id: number): Promise<void> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    motosList = motosList.filter((moto) => moto.id !== id);
  } catch (error) {
    console.error("Erro ao excluir moto:", error);
    throw error;
  }
};

