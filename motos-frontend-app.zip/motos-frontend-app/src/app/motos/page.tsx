'use client';
import Botao from "@/components/motos/botao";
import Formulario from "@/components/motos/formulario";
import Layout from "@/components/motos/layout";
import Tabela from "@/components/motos/tabela";
import Moto from "@/core/Moto";
import { atualizarMoto, cadastrarMoto, excluirMoto, fetchMotos } from "@/service/motoService";
import { useEffect, useState } from "react";



export default function Motos() {

  const [moto, setMoto] = useState<Moto>(Moto.vazio())
  const [visivel, setVisivel] = useState<'tabela' | 'form'>('tabela')

  const [motos, setMotos] = useState<Moto[]>([]);

  useEffect(() => {
    if (visivel === 'tabela') {
      const loadMotos = async () => {
        try {
          const dados = await fetchMotos();
          setMotos(dados);
        } catch (error) {
          console.error("Erro ao buscar motos:", error);
        }
      }

      loadMotos();
    }
  }, [visivel]);


  function motoSelecionado(moto: Moto) {
    setMoto(moto)
    setVisivel('form')
  }

  async function motoExcluido(moto: Moto) {
    const confirmacao = window.confirm("Tem certeza de que deseja excluir este moto?");
    if (confirmacao) {
      try {
        if (moto.id !== null) {
          await excluirMoto(moto.id);
        } else {
          console.error("motoId é null!");
        }
        setMotos(prevMotos => prevMotos.filter(ev => ev.id !== moto.id));
      } catch (error) {
        console.error("Erro ao excluir moto:", error);
      }
    }
  }

  function salvarOuAlterarMoto(moto: Moto) {
    if (moto.id) {
      alterarMoto(moto)
    } else {
      salvarMoto(moto)
    }
  }

  async function alterarMoto(moto: Moto) {
    try {
      const motoAtualizado = await atualizarMoto(moto);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao atualizar moto:", error);
    }
  }

  async function salvarMoto(moto: Moto) {
    try {
      const novoMoto = await cadastrarMoto(moto);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao salvar moto:", error);
    }
  }

  function novoMoto() {
    setMoto(Moto.vazio())
    setVisivel("form")
  }

  return (
    <div className={`
     flex justify-center items-center h-screen
     bg-gradient-to-bl from-indigo-900 via-indigo-400 to-indigo-900
     text-white`}
     style={{
      backgroundImage: 'url(\'S1000RR.jpg\')',
      backgroundSize: 'cover',
     }}>
      <Layout titulo="Cadastro de motos">
        {visivel === 'tabela' ? (
          <>
            <div className="flex justify-end">
              <Botao className="mb-4" cor="text-gray-200
            bg-gradient-to-r from-red-500 to-indigo-800"
                onClick={() => novoMoto()}>
                Nova moto
              </Botao>
            </div>
            <Tabela motos={motos}
              motoSelecionado={motoSelecionado}
              motoExcluido={motoExcluido}></Tabela>
          </>
        ) : (
          <Formulario moto={moto}
            motoMudou={salvarOuAlterarMoto}
            cancelado={() => setVisivel('tabela')} />
        )}
      </Layout>
    </div>
  )

  
}
