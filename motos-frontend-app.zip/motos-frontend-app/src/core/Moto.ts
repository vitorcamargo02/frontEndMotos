import { stringParaEntradaDeData } from "@/utils/converters";

export default class Moto {
    id: number | null;
    modelo: string;
    ano: string;
    status: string;

    constructor(id: number | null, modelo: string, 
        ano: string, status: string) {
        this.id = id;
        this.modelo = modelo;
        this.ano = ano;
        this.status = status;
    }

    static geraMotosMock() {
        return [
            new Moto(1, "CBR 1000 RR-R",
            "A moto com mais R",
            "Vendida",
          ),
          new Moto(2, "S1000RR",
            "A moto mais rapida",
            "Disponivel",
          )
        ]
      }


    static vazio(): Moto {
      return new Moto(null, "",  "", "");
    }
}