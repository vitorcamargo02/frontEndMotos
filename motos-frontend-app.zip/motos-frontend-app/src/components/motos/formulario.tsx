import Moto from "@/core/Moto";
import Entrada from "./entrada";
import { useState } from "react";
import Botao from "./botao";

interface FormularioProps {
    moto: Moto
    motoMudou?: (moto: Moto) => void
    cancelado?: () => void
}

export default function Formulario(props: FormularioProps) {
    const id = props.moto?.id
    const [modelo, setModelo] = useState(props.moto?.modelo)
    const [ano, setAno] = useState(props.moto?.ano)
    const [status, setStatus] = useState(props.moto?.status)

    return (
        <div>
            {id ? (<Entrada texto="id" valor={id} somenteLeitura></Entrada>) : false}
            <Entrada texto="Modelo" valor={modelo} onChange={setModelo}></Entrada>
            <Entrada texto="Ano" valor={ano} onChange={setAno}></Entrada>
            <Entrada texto="Status" valor={status} onChange={setStatus}></Entrada>
            <div className="flex justify-end mt-5">
                <Botao className="mr-3" cor="bg-gradient-to-r from-blue-500 to-blue-700"
                    onClick={() => props.motoMudou?.(new Moto(
                        id, modelo, ano, status))}>
                    {id ? 'Alterar' : 'Salvar'}
                </Botao>
                <Botao cor="bg-gradient-to-r from-gray-500 to-gray-700"
                    onClick={props.cancelado}>
                    Cancelar
                </Botao>
            </div>
        </div>
    )
}